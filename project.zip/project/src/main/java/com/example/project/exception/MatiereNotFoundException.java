package com.example.project.exception;

public class MatiereNotFoundException extends Exception {
    public MatiereNotFoundException (String message) {
        super(message);
    }
}
